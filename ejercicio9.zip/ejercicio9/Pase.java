package ejercicio9;

public class Pase extends Tarjeta {
	private double dto1 , dto2;
	private int limitediasDemora;
	

	public Pase(int diasDemora) {
		super(diasDemora);
		this.limitediasDemora = 5;
		this.dto1 = 0.15;
		this.dto2 = 0.12;
	}


	@Override
	public double devolverDescuento() {
		double dto = this.dto1;
		
		if (this.limitediasDemora > this.getDiasDemora()) {
			dto = this.dto2;
		}
		
		return dto;
	}

}
