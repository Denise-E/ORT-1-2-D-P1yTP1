package ejercicio9;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
