package ejercicio9;

import java.util.ArrayList;


public class EstacionPeaje {
	@SuppressWarnings("unused")
	private int id;
	@SuppressWarnings("unused")
	private String descripcion;
	private ArrayList<Cabina> cabinas;
	
	public EstacionPeaje(int id, String descripcion) {
		this.id = id;
		this.descripcion = descripcion;
		this.cabinas = new ArrayList<>();
	}
	
	public static int dameHoraActual() {
		return (int) (Math.random()*(25));
	}

	public void listarCantidadDeCabinasDeEfectivo() {
		for (Cabina cabina : cabinas) {
			if (cabina.sosCabinaDeEfectivo()) {
				System.out.println("La cabina: " + this + " es de efectivo");
			}
		}
	}

	public double calcularPromedioDemora() {
		int contador = 0;
		int sumatoria = 0;
		
		for (Cabina cabina : cabinas) {
			if(cabina.tenesMedioDePagoTarjeta()) {
				contador++;
				sumatoria += cabina.traerDiasDemora();
			}		
		}
		return (double) (sumatoria/contador);
	}

	
	
	

}
