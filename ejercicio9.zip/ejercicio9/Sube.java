package ejercicio9;

public class Sube extends Tarjeta {
	private double dto;
	
	public Sube(int diasDemora) {
		super(diasDemora);
		this.dto = 0.1;
	}

	@Override
	public double devolverDescuento() {
		return this.dto;
	}

}
