package ejercicio9;

import java.util.ArrayList;

public class Empresa {
	private ArrayList<EstacionPeaje> estaciones;
	
	public Empresa() {
		this.estaciones = new ArrayList<>();
	}
	
	public void cabinasConEfectivo() {
		System.out.println("Las cabinas de efectivo son: ");
		for (EstacionPeaje estacionPeaje : estaciones) {
			System.out.println("De la estacion: " + estacionPeaje);
			estacionPeaje.listarCantidadDeCabinasDeEfectivo();
		}
	}
	
	public double promedioDemora() {
		double resultado = 0;
		for (EstacionPeaje estacionPeaje : estaciones) {
			resultado+= estacionPeaje.calcularPromedioDemora();
		}
		return resultado;
	}
	
}
