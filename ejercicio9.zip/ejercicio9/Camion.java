package ejercicio9;

public class Camion extends Vehiculo {
	private double tarifa;
	
	public Camion(String patente) {
		super(patente);
		this.tarifa = 150;
	}

	@Override
	public double devolverTarifa() {
		return this.tarifa;
	}

}
