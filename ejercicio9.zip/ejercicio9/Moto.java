package ejercicio9;

public class Moto extends Vehiculo {
	private double tarifa;
	

	public Moto(String patente, double tarifa) {
		super(patente);
		this.tarifa = 50;
	}


	@Override
	public double devolverTarifa() {
		return this.tarifa;
	}

}
