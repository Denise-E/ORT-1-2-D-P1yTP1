package ejercicio9;

public abstract class MedioDePago {
	
	public abstract double devolverDescuento();
}
