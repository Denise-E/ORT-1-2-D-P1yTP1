package ejercicio9;

public abstract class Vehiculo {
	@SuppressWarnings("unused")
	private String patente;

	public Vehiculo(String patente) {
		this.patente = patente;
	}
	
	public abstract double devolverTarifa();
	
}
