package ejercicio9;

public class Cabina {
	@SuppressWarnings("unused")
	private int id;
	private MedioDePago medioDePago;
	
	public Cabina(int id, MedioDePago medioDePago) {
		this.id = id;
		this.medioDePago = medioDePago;
	}
	
	public double cobrar(Vehiculo vehiculoACobrar) {
		double monto;
		final double INCREMENTO_HORA_PICO = 0.08;
		
		monto = calcularTarifa(vehiculoACobrar) * calcularDescuento();
		if (horaPico()) {
			monto *= (1+ INCREMENTO_HORA_PICO);
		}
		
		return monto;
	}
	
	private double calcularTarifa(Vehiculo vehiculo) {
		return vehiculo.devolverTarifa();
	}
	
	private double calcularDescuento() {
		return medioDePago.devolverDescuento();
	}
	
	private boolean horaPico() {
		final int 
		HORARIO_MINIMO_MANIANA = 6,
		HORARIO_MAXIMO_MANIANA = 10,
		HORARIO_MINIMO_TARDE = 17,
		HORARIO_MAXIMO_TARDE = 20;
		int horaActual = EstacionPeaje.dameHoraActual();
		
		return ((HORARIO_MINIMO_MANIANA < horaActual && horaActual < HORARIO_MAXIMO_MANIANA)||(HORARIO_MINIMO_TARDE < horaActual && horaActual < HORARIO_MAXIMO_TARDE));
	}

	public boolean sosCabinaDeEfectivo() {
		return this.getMedioDePago() instanceof Efectivo;
	}

	public MedioDePago getMedioDePago() {
		return medioDePago;
	}

	public boolean tenesMedioDePagoTarjeta() {
		return this.getMedioDePago() instanceof Tarjeta;
	}

	public int traerDiasDemora() {
		return ((Tarjeta)medioDePago).getDiasDemora();
	}

}
