package ejercicio9;

public class Efectivo extends MedioDePago {
	private int dto;
	
	public Efectivo() {
		super();
		this.dto = 0;
	}

	@Override
	public double devolverDescuento() {
		return this.dto;
	}

}
