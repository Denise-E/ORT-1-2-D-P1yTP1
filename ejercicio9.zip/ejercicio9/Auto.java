package ejercicio9;

public class Auto extends Vehiculo {
	private double tarifa;
	
	public Auto(String patente, double tarifa) {
		super(patente);
		this.tarifa = 100;
	}

	@Override
	public double devolverTarifa() {
		// TODO Auto-generated method stub
		return this.tarifa;
	}

}
