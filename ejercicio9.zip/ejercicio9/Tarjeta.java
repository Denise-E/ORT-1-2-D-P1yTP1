package ejercicio9;

public abstract class Tarjeta extends MedioDePago {
	private int diasDemora;

	public Tarjeta(int diasDemora) {
		this.diasDemora = diasDemora;
	}

	public int getDiasDemora() {
		return diasDemora;
	}
	
	
}
